package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDaoImplementation;
import com.cg.mra.dao.IAccountDao;
import com.cg.mra.exception.InvalidMobileNumberException;

import com.cg.mra.service.AccountServiceImplementation;
import com.cg.mra.service.IAccountService;


public class MainUI {
	private static Scanner scanner = new Scanner(System.in);
	private static IAccountDao idao = new AccountDaoImplementation();
	private static IAccountService iservice = new AccountServiceImplementation(idao);
 
	public static void main(String[] args) throws InvalidMobileNumberException{
	
		//******************************************************//
		//int choice = scanner.nextInt();
		while (true) {
//			switch (choice) {
//			case 1:
//				rechargeAmount();
//				break;
//			case 2:getAccountDetails();
//			  break;
//			case 3:
//				System.exit(0);
//				break;
//			}
			System.out.println("Enter your choice");
			int choice=scanner.nextInt();
			switch(choice)
			{
			case 1: System.out.println("Enter mobile number");
				String mobileno=scanner.next();
				System.out.println(iservice.getAccountDetails(mobileno));
				break;
			case 2: System.out.println("Enter mobile number");
				String mobno=scanner.next();
				System.out.println("Enter amount");
				double amount=scanner.nextDouble();
				System.out.println(iservice.rechargeAccount(mobno,amount));
				break;
			case 3: System.exit(0);
				break;
			}
			System.out.println("exit successfully");

		}

	}


//	private static void getAccountDetails() throws InvalidMobileNumberException {
//		System.out.println("Enter the mobileNumber");
//		String mobileNo=scanner.nextLine();
//		iservice.getAccountDetails(mobileNo);
//		
//	}
//
//
//
//
//	private static void rechargeAmount() throws InvalidMobileNumberException{
//		Account account=new Account();
//		System.out.println("Enter the mobileNumber");
//		String mobileNo=scanner.next();
//		
//		System.out.println("Enter the rechargeAmount");
//		double rechargeAmount=scanner.nextDouble();
//		iservice.rechargeAccount(mobileNo, rechargeAmount);
//		System.out.println("Hiii!!! your balance is"+account.getAccountBalance());
//		
//		
//	}

}

package com.cg.mra.dao;

import java.util.HashMap;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.InvalidMobileNumberException;

public class AccountDaoImplementation implements IAccountDao{
	HashMap <String, Account>accountEntry;	
	public AccountDaoImplementation()
	{
		accountEntry=new HashMap<>();  //There is some duplicate values of mobileNumber so we have changed them
		accountEntry.put("7500725707", new Account( "Prepaid", "Vaishali", 200));
		accountEntry.put("9823920123", new Account("Prepaid", "Megha", 453));
		accountEntry.put("9932012345", new Account("Prepaid", "Vikas", 631));
		accountEntry.put("9010210131", new Account("Prepaid", "Anju", 521));
		accountEntry.put("9956321397", new Account("Prepaid", "Tushar", 632));
	}

	@Override
	public Account getAccountDetails(String mobileNo) throws InvalidMobileNumberException {
//		for(Entry<String, Account> entry:accountEntry.entrySet())
//			if( entry.getKey().equals(mobileNo))
//				return  entry.getValue();

		if(accountEntry.get(mobileNo)==null) {
			throw new InvalidMobileNumberException();
		}
		return accountEntry.get(mobileNo);	
	}

	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) throws InvalidMobileNumberException{
		Account account=accountEntry.get(mobileNo);
		if(account==null) {
			throw new InvalidMobileNumberException();
		}
		 account.setAccountBalance(account.getAccountBalance()+rechargeAmount);
     return  account.getAccountBalance();
	}

	}

